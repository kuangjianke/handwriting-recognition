import os
from PIL import Image
import numpy as np
import tensorflow as tf

def read_image(img_name):
    im = Image.open(img_name).convert('L')
    data=np.array(im)
    return data

def read_lable(img_name):
    basename = os.path.basename(img_name)
    data = basename.split('_')[0]
    return data
images=[]
lables=[]
for fn in os.listdir('cb'):
    if fn.endswith('.png'):
        fd=os.path.join('cb',fn)
        images.append(read_image(fd))
        lables.append(int(read_lable(fd)))

y_test=np.array(lables)
x_test=np.array(images)


model = tf.keras.models.load_model('11.h5')
predictions = model.predict(x_test)

acc=[]
ac=[]
for j,i in enumerate(range(len(y_test))):
    acc.append(int(np.argmax(predictions[i])))
    ac.append(y_test[j])
print('正确答案',ac)
print('预测答案',acc)



