import os#系统模块
from PIL import Image#用于图片的读取，转换
import numpy as np
import tensorflow as tf
from tensorflow import keras

def read_image(img_name):#提取图片
    im = Image.open(img_name).convert('L')#打开图片，转黑白
    data=np.array(im)#改成2维
    return data

def read_lable(img_name):#取标签
    basename = os.path.basename(img_name)#图片名称
    data = basename.split('_')[0]#对图片名称切片
    return data

images=[]#创建数组用于存放图片数据
lables=[]#放标签
for fn in os.listdir('ca'):#循环文件中的图片
    if fn.endswith('.png'):#判断后缀为png的图片格式
        fd=os.path.join('ca',fn)#重租图片路径
        images.append(read_image(fd))#用取图片的方法，取每个图片的每个数据点
        lables.append(int(read_lable(fd)))#取标签

y_train=np.array(lables)#转2维数组
y_test=y_train#用训练数据进行测试

x_train=np.array(images)
x_test=x_train

train_images = x_train / 255.0#2维数据的点缩小到0和1之间
test_images = x_test / 255.0

# 使用keras的sequential设置网络结构
model = keras.Sequential([
    keras.layers.Flatten(input_shape=(28, 28)),#定义输入的形状
    keras.layers.Activation(activation=tf.nn.relu),#设定激活函数
    keras.layers.Dense(512),#设置神经网络层
    keras.layers.Activation(activation=tf.nn.relu),
    keras.layers.Dense(128),
    keras.layers.Activation(activation=tf.nn.relu),
    keras.layers.Dense(10),
     keras.layers.Activation(activation=tf.nn.softmax),
    keras.layers.Dropout(0.002)#设置优化器学习率
])
# 编译模型
model.compile(optimizer=tf.train.AdamOptimizer(),#使用梯度下降法，也可以设置其他的方法
              #tf.train.GradientDescentOptimizer()使用随机梯度下降算法
              loss='sparse_categorical_crossentropy',#使用二次代价函数或交叉熵等方法#损失函数，交叉熵
              metrics=['accuracy'])#衡量工具
# 训练模型
model.fit(train_images, y_train, epochs=500,batch_size=232)#传入训练图片数据和标签，还有训练次数和一次性的数量
# 测试模型
test_loss, test_acc = model.evaluate(test_images, y_test)#降测试的数据穿入
print('Test accuracy:',test_acc)
# 保存模型文件
model.save('11.h5')
